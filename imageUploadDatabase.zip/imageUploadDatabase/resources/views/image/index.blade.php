<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image upload</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css">
      <!-- Font Awesome open -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css"/>
  <!-- Font Awesome open -->
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-2">
                <div class="card bg-light shadow mt-2">
                    <div class="card-body">
                        <p> <a href="{{ route('image.create') }}"
                                class="btn btn-outline-primary">upload Image</a> </p>
                    </div>
                </div>
            </div>
            <div class="col-10">
                <!---- message will be display open - -->
                @if(session('success'))
                    <div class="alert alert-success alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                        {{ session('success') }}
                    </div>
                @endif
                <!-- message will be display close -->
                <!---- error message open -- -->
                @if(isset($errors))
                    @if(count($errors) >0 )
                        @foreach($errors->all() as $error)
                            <div class="alert alert-danger alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                {{ $error }}
                            </div>
                        @endforeach
                    @endif
                @endif
                <!-- {{-- error message close --}} -->
                <div class="card">
                    <div class="card-body">
                        <table class="table table-striped">
                            <tr>
                                <th>Id</th>
                                <th>Email</th>
                                <th>Message</th>
                                <th>Logo</th>
                                <th>Action</th>
                            </tr>
                            @foreach($gettFile as $files )
                                <tr>
                                    <td>{{ $files->id }}</td>
                                    <td>{{ $files->email }}</td>
                                    <td>{{ $files->message }}</td>
                                    <td>
                                        <img src="{{ url('storage/imageStorePath/',$files->docImage) }}"
                                            width="70" height="40">
                                    </td>
                                    <td>
                                        <span> <a href="" class="nav-icon fa fa-edit text-success fa-2x"
                                                title="edit"></a></span>
                                        <span> <a href="" class="nav-icon fa fa-trash text-danger fa-2x"
                                                title="delete"></a></span>
                                        <span> <a href="" class="nav-icon fa fa-file text-warning fa-2x"
                                                title="view"></a></span>
                                    </td>
                                </tr>
                            @endforeach
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
