<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image upload</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css">
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-2">
                <div class="card bg-light shadow mt-2">
                    <div class="card-body">
                        <p> <a href="{{ route('image.create') }}"
                                class="btn btn-outline-primary">upload Image</a> </p>
                    </div>
                </div>
            </div>
            <div class="col-10">
                <!-- {{-- error message open --}} -->
                @if(isset($errors))
                    @if(count($errors) >0 )
                        @foreach($errors->all() as $error)
                            <div class="alert alert-danger alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                {{ $error }}
                            </div>
                        @endforeach
                    @endif
                @endif
                <!-- {{-- error message close --}} -->
                <div class="card">
                    <div class="card-body">
                        <form action="{{ route('image.store') }}" method="POST"
                            enctype="multipart/form-data">
                            @csrf
                            <div class="form-group">
                                <label for="email">User Email : </label>
                                <input type="email" class="form-control" name="email" placeholder="Enter email">
                            </div>

                            <div class="form-group">
                                <label for="message">User Message : </label>
                                <textarea name="message" class="form-control" cols="20" rows="4"></textarea>
                            </div>
                            <div class="form-group">
                                <label for="docImage">docImage</label>
                                <input type="file" class="form-control" name="docImage">
                            </div>
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
