<?php

namespace App\Http\Controllers;

use App\Models\Imageupload;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class ImageuploadController extends Controller
{
    public function index(){
        $gettFile = Imageupload::all();
        return view('image.index',compact('gettFile'));
    }

    public function create(){
        return view('image.create');
    }

    public function imageStore(Request $request){
        $this->validate($request,[
            'email' => 'required|email',
            'message' => 'required',
            'docImage' => 'required',
        ]);
        $gettingImage = time() . '.' . $request['docImage']->getClientOriginalExtension();
        $DocumentPath = $request['docImage']->move(base_path() . '/storage/app/public/imageStorePath', $gettingImage);

        $doc = new Imageupload();
        $doc->email = $request->email;
        $doc->message = $request->message;
        $doc->docImage = $gettingImage;
        $doc->save();
        Log::info('image save succefully with any issues');
        return redirect()->route('index.page')->with('success','Document File has been save succeefully');

    }
}
